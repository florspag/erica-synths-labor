Rename file "LABTEMP1-cache" to "LABTEMP1-cache.lib"
